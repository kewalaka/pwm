define({
	dgridUrl: 'http://dgrid.io',
	docBaseUrl: 'https://github.com/SitePen/dgrid/blob/dev-0.4/doc/'
});
